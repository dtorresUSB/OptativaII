from flask import Flask, render_template, request
import hashlib
import controlador
from datetime import datetime
import random
import envioemail

app = Flask(__name__)

origen=""

@app.route("/")
def hello_world():
    return render_template("login.html")

@app.route("/verificarUsuario",methods=["GET","POST"])
def verificarUsuario():
    correo=request.form["txtusuario"]
    correo=correo.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    password=request.form["txtpass"]
    password=password.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    
    password2=password.encode()
    password2=hashlib.sha384(password2).hexdigest()
        
    respuesta=controlador.comprobarusuario(correo,password2) 
    
    global origen
    
    if len(respuesta)==0:
        origen=""
        mensaje="Error de Autenticacion, por favor verifica tu usuario y contraseña"
        return render_template("informacion.html", data=mensaje)
    else:
        origen=correo
        respuesta2=controlador.listaUsuarios(correo)
        return render_template("principal.html", data=respuesta2,infousuario=respuesta)
    
    
@app.route("/registrarUsuario",methods=["GET","POST"])
def registrarUsuario():
    nombre=request.form["txtnombre"]
    nombre=nombre.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    correo=request.form["txtusuarioregistro"]
    correo=correo.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    password=request.form["txtpassregistro"]
    password=password.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    
    password2=password.encode()
    password2=hashlib.sha384(password2).hexdigest()
    
    codigo=datetime.now()
    
    codigo2=str(codigo)
    codigo2=codigo2.replace("-","")    
    codigo2=codigo2.replace(":","")    
    codigo2=codigo2.replace(".","")    
    codigo2=codigo2.replace(" ","")    
    
    codigo3=random.randint(10000,30000)
        
    res_regis=controlador.regisUsu(nombre,correo,password2,codigo2)
    
    if res_regis=="1":
        asunto="Codigo de Activacion"
        mensaje="Sr, usuario su codigo de activacion es :\n\n"+codigo2+ "\n\n Recuerde copiarlo y pegarlo para validarlo en la seccion de login y activar su cuenta.\n\nMuchas Gracias"
        res_correo=envioemail.enviar(correo,asunto,mensaje)
        if res_correo=="1":
            mensaje="Usuario Registrado Satisfactoriamente"
        else:
            mensaje="Usuario Registrado con Exito. Se presento un error al enviar el correo. Servicio no disponible. utiliza el siguiente codigo de activacion = "+codigo2
    else:
        mensaje="ERROR!!!, no fue posible realizar el registro, debido a que el usuario y/o correo Existen."
    
    return render_template("informacion.html", data=mensaje)


@app.route("/activarUsuario",methods=["GET","POST"])
def activarUsuario():
    codigo=request.form["txtcodigo"]
    codigo=codigo.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    
    controlador.activarU(codigo)    
    
    mensaje="Usuario activado satisfactoriamente"
    return render_template("informacion.html", data=mensaje)

@app.route("/enviarEE",methods=["GET","POST"])
def enviarEE():
    asunto=request.form["asunto"]
    asunto=asunto.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    mensaje=request.form["mensaje"]
    mensaje=mensaje.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    destino=request.form["destino"]
    destino=destino.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    
    controlador.regisMensaje(asunto,mensaje,origen,destino)
    
    asunto2="Nuevo Mensaje Recibido"
    mensaje2="Sr usuario ingrese a la plataforma para que pueda observar su nuevo mensaje.\n\n Muchas Gracias."
    envioemail.enviar(destino,asunto2,mensaje2)
    
    return "Email enviado satisfactoriamente..."


@app.route("/correoEnviados",methods=["GET","POST"])
def correoEnviados():
    
    respuesta=controlador.enviados(origen)
    
    return render_template("historial.html",listacorreos=respuesta)

@app.route("/correoRecibidos",methods=["GET","POST"])
def correoRecibidos():
    
    respuesta=controlador.recibidos(origen)
    
    return render_template("historial.html",listacorreos=respuesta)


@app.route("/actualizarPass",methods=["GET","POST"])
def actualizarPass():
    password=request.form["password"]
    password=password.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
    
    password2=password.encode()
    password2=hashlib.sha384(password2).hexdigest()
    
    controlador.actualizaP(password2,origen)
    
    return "Contraseña Actualizada Correctamente"
   