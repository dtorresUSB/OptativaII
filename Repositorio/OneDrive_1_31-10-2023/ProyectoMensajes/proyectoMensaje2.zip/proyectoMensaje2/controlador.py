import sqlite3

def comprobarusuario(correo,password):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="select *from usuarios where correo='"+correo+"' and password='"+password+"' and estado='1'"
    cursor.execute(consulta)
    resultado=cursor.fetchall()
    return resultado

def enviados(correo):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="select  m.asunto, m.mensaje, m.fecha, m.hora, u.nombreusuario  from mensajeria m, usuarios u where u.correo=m.destino and m.origen='"+correo+"'"
    cursor.execute(consulta)
    resultado=cursor.fetchall()
    return resultado

def recibidos(correo):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="select  m.asunto, m.mensaje, m.fecha, m.hora, u.nombreusuario  from mensajeria m, usuarios u where u.correo=m.origen and m.destino='"+correo+"'"
    cursor.execute(consulta)
    resultado=cursor.fetchall()
    return resultado

def listaUsuarios(correo):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="select *from usuarios where estado='1' and correo<>'"+correo+"'"
    cursor.execute(consulta)
    resultado=cursor.fetchall()
    return resultado

def actualizaP(passw,correo):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="update usuarios set password='"+passw+"' where correo='"+correo+"'"
    cursor.execute(consulta)
    db.commit()
    return "1"


def regisUsu(nombre,correo,password,codigo):
    
    try:
        db=sqlite3.connect("mensajes.s3db")
        db.row_factory=sqlite3.Row
        cursor=db.cursor()
        consulta="insert into usuarios (nombreusuario,correo,password,estado,codigoactivacion) values ('"+nombre+"','"+correo+"','"+password+"','0','"+codigo+"')"
        cursor.execute(consulta)
        db.commit()
        return "1"
    except :
        return "0"
        
    
    

def regisMensaje(asunto,mensaje,origen,destino):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="insert into mensajeria (asunto, mensaje, fecha, hora, origen, destino, estado) values ('"+asunto+"','"+mensaje+"',DATE('now'),TIME('now'),'"+origen+"','"+destino+"','0')"
    cursor.execute(consulta)
    db.commit()
    return "1"

def activarU(codigo):
    db=sqlite3.connect("mensajes.s3db")
    db.row_factory=sqlite3.Row
    cursor=db.cursor()
    consulta="update usuarios set estado='1' where codigoactivacion='"+codigo+"'"
    cursor.execute(consulta)
    db.commit()
    
    return "1"